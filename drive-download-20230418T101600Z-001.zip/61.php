
<?php
//連線資料庫並讀取資料表
$servername = "localhost"; //伺服器連線名
$username = "root"; //資料庫使用者名稱
$password = "david20515"; //資料庫密碼
$dbname = "project"; //資料庫名
$conn = new mysqli($servername, $username, $password, $dbname); //連線資料庫
echo "<table border='2' bordercolor='#66ccff'>";
if (!$conn) {
	die("連線失敗：" . mysqli_connect_error()); //連線資料庫失敗則殺死程序
}
$sql = "SELECT Distinct * FROM user where Subject ='作業研究'"; //查詢語句--查詢資料庫表
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
		echo "<tr>";
		echo "<td>Domain:" . $row["Domain"] . "</td><td>Subject:" . $row["Subject"] . "</td><td>Professor:" . $row["Professor"] . "</td><td>ClassNo:" . $row["ClassNo"] . "</td><td>Dept：" . $row["Dept"] . "</td>";
		echo "</tr>";
	}
} else {
	echo "0 結果";
}

echo "</table>";
echo "<form name=\"form\" method=\"post\" action=\"final.php\">";
        
        echo "<input type=\"submit\" name=\"button\" value=\"結束\" />";
mysqli_close($conn); //關閉資料庫
?>