<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include("connMySQL.php");

$name = $_POST['name'];
$DM = $_POST['DM'];
$SJ = $_POST['SJ'];
$PN = $_POST['PN'];
$UN= $_POST['UN'];
$CN = $_POST['CN'];
$GR = $_POST['GR'];
$CMT = $_POST['CMT'];
if($name != null && $DM != null && $SJ != null && $CMT !=NULL)
{
        $sql = "insert into user (Student, Domain, Subject, Professor, Dept, ClassNo, Grade,Comment) values ('$name', '$DM', '$SJ', '$PN', '$UN','$CN', '$GR', '$CMT')";
        if($conn->query($sql) == TRUE)
        {
                echo '<br>新增留言成功!';
                echo '<meta http-equiv=REFRESH CONTENT=2;url=final.php>';
        }
        else
        {
                echo '留言新增失敗!';
                echo '<meta http-equiv=REFRESH CONTENT=2;url=final.php>';
        }
}

else
{
        echo '請輸入完整資訊!';
        echo '<meta http-equiv=REFRESH CONTENT=2;url=final.php>';
}
?>