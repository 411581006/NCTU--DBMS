<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<form name="form" method="post" action="register_finish.php">
學生學號及名稱 std's name and id：<input type="text" name="name" /> <br>
領域 domain：<input type="text" name="DM" /> <br>
授課科目 subject：<input type="text" name="SJ" /> <br>
授課教授 professor's name：<input type="text" name="PN" /> <br>
所屬單位 dept：<input type="text" name="UN" /> <br>
課號 class no：<input type="text" name="CN" /> <br>
評分等級(S，A+，A，A-，B，C) grade：<input type="text" name="GR" /> <br>
評價(50字以內) comment：<input type="text" name="CMT" /> <br>
<input type="submit" name="button" value="確定" />
</form>

