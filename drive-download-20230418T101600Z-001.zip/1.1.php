<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<form name="form" method="post" action="1.php">
教授姓名：<input type="text" name="PN" /> <br>

<input type="submit" name="button" value="確定" />
</form>