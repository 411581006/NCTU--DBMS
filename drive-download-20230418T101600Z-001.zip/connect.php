<?php
   include ("connMySQL.php");
   $name = $_POST['name'];
   $pw = $_POST['pw'];
   if(isset($name) && isset($pw)){
       $sql ="SELECT username,Password FROM user WHERE username='$name'";                    
       $result = $conn->query($sql);
           if($result->num_rows > 0){
               while($row = $result->fetch_assoc()){
                   if($row["username"]==$name&&$row["Password"]==$pw){
                       echo "登入成功！ 歡迎使用本系統";
                   }else{ 
                       echo "登入失敗！";
                   }
               }
           }else{
               echo "資料庫連接失敗";
           }
   }else{
       echo "未輸入帳號密碼";
   }
