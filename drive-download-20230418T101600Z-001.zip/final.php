<!DOCTYPE html>
<html lang="en">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="STYLESHEET" type="text/css" href="dba_style/buttons.css" />
    <title>管院選課之葵花寶典</title>
    <link rel="stylesheet" href="css/main.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="http://code.jquery.com/jquery-1.8.0.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <SCRIPT LANGUAGE="JavaScript">
    
      function clo(){
      document.getElementById('1').style.display = "none";
      document.getElementById('2').style.display = "none";
      document.getElementById('3').style.display = "none";
      document.getElementById('4').style.display = "none";
      document.getElementById("5").style.display = "none";
      document.getElementById("6").style.display = "none";
  

      //setTimeout("do_clo()",1000 );
      //setTimeout("rep()",1000 );
       }
      function do_change(){

     document.getElementById("1").style.display = "block";
    document.getElementById("2").style.display = "block";
    document.getElementById("3").style.display = "block";
    document.getElementById("4").style.display = "block";
    document.getElementById("5").style.display = "block";
    document.getElementById("6").style.display = "block";
   
      }
      function do_change1(){
 
 document.getElementById("31").style.display = "block";

  }
      function btn1(){
 
 document.getElementById("7").style.display = "block";
document.getElementById("8").style.display = "block";
document.getElementById("9").style.display = "block";
document.getElementById("10").style.display = "block";
document.getElementById("11").style.display = "block";
document.getElementById("26").style.display = "block";
document.getElementById("31").style.display = "block";
document.getElementById("32").style.display = "block";
document.getElementById("33").style.display = "block";
document.getElementById("39").style.display = "block";
document.getElementById("40").style.display = "block";
document.getElementById("41").style.display = "block";
document.getElementById("42").style.display = "block";
document.getElementById("43").style.display = "block";
document.getElementById("44").style.display = "block";
document.getElementById("45").style.display = "block";
document.getElementById("46").style.display = "block";
document.getElementById("47").style.display = "block";
document.getElementById("48").style.display = "block";
document.getElementById("49").style.display = "block";
document.getElementById("50").style.display = "block";
document.getElementById("51").style.display = "block";
document.getElementById("52").style.display = "block";
document.getElementById("53").style.display = "block";
document.getElementById('1').style.display = "none";
      document.getElementById('2').style.display = "none";
      document.getElementById('3').style.display = "none";
      document.getElementById('4').style.display = "none";
      document.getElementById("5").style.display = "none";
      document.getElementById("6").style.display = "none";


  }
  function clo1(){
    document.getElementById("7").style.display = "none";
document.getElementById("8").style.display = "none";
document.getElementById("9").style.display = "none";
document.getElementById("10").style.display = "none";
document.getElementById("11").style.display = "none";
document.getElementById('1').style.display = "block";
      document.getElementById('2').style.display = "block";
      document.getElementById('3').style.display = "block";
      document.getElementById('4').style.display = "block";
      document.getElementById("5").style.display = "block";
      document.getElementById("6").style.display = "block";
      document.getElementById("26").style.display = "none";
      document.getElementById("31").style.display = "none";
      document.getElementById("32").style.display = "none";
      document.getElementById("33").style.display = "none";
      document.getElementById("39").style.display = "none";
document.getElementById("40").style.display = "none";
document.getElementById("41").style.display = "none";
document.getElementById("42").style.display = "none";
document.getElementById("43").style.display = "none";
document.getElementById("44").style.display = "none";
document.getElementById("45").style.display = "none";
document.getElementById("46").style.display = "none";
document.getElementById("47").style.display = "none";
document.getElementById("48").style.display = "none";
document.getElementById("49").style.display = "none";
document.getElementById("50").style.display = "none";
document.getElementById("51").style.display = "none";
document.getElementById("52").style.display = "none";
document.getElementById("53").style.display = "none";
  }
  function btn2(){
 
 document.getElementById("12").style.display = "block";
document.getElementById("13").style.display = "block";
document.getElementById("14").style.display = "block";
document.getElementById("15").style.display = "block";
document.getElementById("27").style.display = "block";
document.getElementById("54").style.display = "block";
document.getElementById("55").style.display = "block";
document.getElementById("56").style.display = "block";
document.getElementById("57").style.display = "block";
document.getElementById("58").style.display = "block";
document.getElementById("59").style.display = "block";
document.getElementById("60").style.display = "block";
document.getElementById("61").style.display = "block";
document.getElementById('1').style.display = "none";
document.getElementById('2').style.display = "none";    
      document.getElementById('3').style.display = "none";
      document.getElementById('4').style.display = "none";
      document.getElementById("5").style.display = "none";
      document.getElementById("6").style.display = "none";

  }
  function clo2(){
    document.getElementById("12").style.display = "none";
document.getElementById("13").style.display = "none";
document.getElementById("14").style.display = "none";
document.getElementById("15").style.display = "none";
document.getElementById('1').style.display = "block";
document.getElementById('2').style.display = "block";
      document.getElementById('3').style.display = "block";
      document.getElementById('4').style.display = "block";
      document.getElementById("5").style.display = "block";
      document.getElementById("6").style.display = "block";
      document.getElementById("27").style.display = "none";
      document.getElementById("54").style.display = "none";
      document.getElementById("55").style.display = "none";
      document.getElementById("56").style.display = "none";
      document.getElementById("57").style.display = "none";
      document.getElementById("58").style.display = "none";
      document.getElementById("59").style.display = "none";
      document.getElementById("60").style.display = "none";
      document.getElementById("61").style.display = "none";
  }
  function btn3(){
    document.getElementById('1').style.display = "none";
      document.getElementById('2').style.display = "none";
      document.getElementById('3').style.display = "none";
      document.getElementById('4').style.display = "none";
      document.getElementById("5").style.display = "none";
      document.getElementById("6").style.display = "none";
 
 document.getElementById("23").style.display = "block";
document.getElementById("24").style.display = "block";
document.getElementById("25").style.display = "block";
document.getElementById("28").style.display = "block";
document.getElementById("36").style.display = "block";
document.getElementById("37").style.display = "block";
document.getElementById("38").style.display = "block";
  }
  function clo3(){
    document.getElementById('1').style.display = "block";
      document.getElementById('2').style.display = "block";
      document.getElementById('3').style.display = "block";
      document.getElementById('4').style.display = "block";
      document.getElementById("5").style.display = "block";
      document.getElementById("6").style.display = "block";
 
 document.getElementById("23").style.display = "none";
document.getElementById("24").style.display = "none";
document.getElementById("25").style.display = "none";
document.getElementById("28").style.display = "none";
document.getElementById("36").style.display = "none";
document.getElementById("37").style.display = "none";
document.getElementById("38").style.display = "none";
  }
  function btn4(){
 
    document.getElementById('1').style.display = "none";
      document.getElementById('2').style.display = "none";
      document.getElementById('3').style.display = "none";
      document.getElementById('4').style.display = "none";
      document.getElementById("5").style.display = "none";
      document.getElementById("6").style.display = "none";
 document.getElementById("20").style.display = "block";
document.getElementById("17").style.display = "block";
document.getElementById("18").style.display = "block";
document.getElementById("19").style.display = "block";
document.getElementById("29").style.display = "block";
document.getElementById("34").style.display = "block";
document.getElementById("35").style.display = "block";
document.getElementById("62").style.display = "block";
document.getElementById("63").style.display = "block";
document.getElementById("64").style.display = "block";
document.getElementById("65").style.display = "block";
document.getElementById("66").style.display = "block";
document.getElementById("67").style.display = "block";
document.getElementById("68").style.display = "block";
document.getElementById("69").style.display = "block";
document.getElementById("70").style.display = "block";
 }
  function clo4(){
    document.getElementById('1').style.display = "block";
      document.getElementById('2').style.display = "block";
      document.getElementById('3').style.display = "block";
      document.getElementById('4').style.display = "block";
      document.getElementById("5").style.display = "block";
      document.getElementById("6").style.display = "block";
 document.getElementById("20").style.display = "none";
document.getElementById("17").style.display = "none";
document.getElementById("18").style.display = "none";
document.getElementById("19").style.display = "none";
document.getElementById("29").style.display = "none";
document.getElementById("34").style.display = "none";
document.getElementById("35").style.display = "none";
document.getElementById("62").style.display = "none";
document.getElementById("63").style.display = "none";
document.getElementById("64").style.display = "none";
document.getElementById("65").style.display = "none";
document.getElementById("66").style.display = "none";
document.getElementById("67").style.display = "none";
document.getElementById("68").style.display = "none";
document.getElementById("69").style.display = "none";
document.getElementById("70").style.display = "none";
  }
  function btn5(){
    document.getElementById('1').style.display = "none";
      document.getElementById('2').style.display = "none";
      document.getElementById('3').style.display = "none";
      document.getElementById('4').style.display = "none";
      document.getElementById('5').style.display = "none";
      document.getElementById("6").style.display = "none";
 
 document.getElementById("21").style.display = "block";
document.getElementById("22").style.display = "block";
document.getElementById("30").style.display = "block";
document.getElementById("71").style.display = "block";
document.getElementById("72").style.display = "block";
document.getElementById("73").style.display = "block";
document.getElementById("74").style.display = "block";

  }
  function clo5(){
    document.getElementById('1').style.display = "block";
      document.getElementById('2').style.display = "block";
      document.getElementById('3').style.display = "block";
      document.getElementById('4').style.display = "block";
      document.getElementById('5').style.display = "block";
      document.getElementById("6").style.display = "block";
 
 document.getElementById("21").style.display = "none";
document.getElementById("22").style.display = "none";
document.getElementById("30").style.display = "none";
document.getElementById("71").style.display = "none";
document.getElementById("72").style.display = "none";
document.getElementById("73").style.display = "none";
document.getElementById("74").style.display = "none";
}
function showDiv1() {document.getElementById('welcomeDiv1').style.display = "block";}
function cloDiv1() { document.getElementById('welcomeDiv1').style.display = "none";}
function showDiv2() { document.getElementById('search').style.display = "block";}
function cloDiv2() {document.getElementById('welcomeDiv2').style.display = "none";}
function showDiv3() {document.getElementById('welcomeDiv3').style.display = "block";}
function cloDiv3() { document.getElementById('welcomeDiv3').style.display = "none";}
</script> 


</script> 
<style>
.button {
  background-color: #514644; /* Green */
  border: none;
  color: white;
  width:200px;height:200px; //正圓形，所以寬與高都設一樣
  float: left;
 border-radius:999em;
  
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
  cursor: pointer;
}

</style>
    

    <style>
        /* unvisited link */
        a:link {
          color: red;
        }
        
        /* visited link */
        a:visited {
          color: green;
        }
        
        /* mouse over link */
        a:hover {
          color: hotpink;
        }
        
        /* selected link */
        a:active {
          color: blue;
        }
     </style>
    
    
    <
    <style>
      *{
  font-family: 'Kumar One Outline', cursive;
}



.centered{
  position:absolute;
  left:50%;
  top:50%;
  transform:translate(-50%,-50%); 
}



 
    </style>
   
  
     <script>
        window.alert("Directing to 管院選課之葵花寶典 ");
    </script>
    <script language="javascript1.2">
      var b_delay = 1000;
      var bannerID;
      var b = 0;
      var b_links = new Array();
      var b_imgs = new Array();
      function LoadB_Imgs(b,img_file){
          b_image = new Image();
          b_image.src = img_file;
          b_imgs[b] = b_image.src;
      }
      LoadB_Imgs(0,"1.jpg");
      LoadB_Imgs(1,"2.2.jpg");
      LoadB_Imgs(2,"3.1.jpg");
      LoadB_Imgs(3,"3.2.jpg");
      LoadB_Imgs(4,"3.92.jpg");
      LoadB_Imgs(5,"3.4.jpg");
      LoadB_Imgs(6,"3.5.jpg");
      LoadB_Imgs(7,"3.6.jpg");
      LoadB_Imgs(8,"3.7.jpg");
      LoadB_Imgs(9,"3.8.jpg");
      LoadB_Imgs(10,"3.9jpg");
      LoadB_Imgs(11,"3.91.jpg");
     
      
      
      function RotateBanner(){
          document.as.src = b_imgs[b];
          if(b >= 11){
                b = 0;
              }
              else{
                b++;
              }
          bannerID = setTimeout("RotateBanner()",b_delay);
      }
      function LoadFunctions(){
          RotateBanner();
      }
     

      
      
      </script>
     


      
      
</head> 
<body>
<body onload = "LoadFunctions()">


<div class="jumbotron jumbotron-fluid">
   
 
<div class="text-center"><h1>管院選課葵花寶典</h1></div>


<div class="section" id="about">
  



<div class="container">
<div class="row">
<div class="col-sm-8">


    <p class="font-weight-normal"><h2><button type="button" class="btn-block" name="edit" id="edit" onclick="do_change(); return false;">
      <p><a href="default.asp" target="_blank">有興趣的領域</a></p>
    </button> </h2></p>
    <button type="button" class="btn-block" name="edit" id="1" onclick="btn1(); return false;">
      <p><a href="default.asp" target="_blank">財金 Finance</a></p>
    </button> 
    <button type="button" class="btn-block" name="edit" id="2" onclick="btn2(); return false;">
      <p><a href="default.asp" target="_blank">資訊 Computer knowledge</a></p>
    </button>
    <button type="button" class="btn-block" name="edit" id="3" onclick="btn3(); return false;">
      <p><a href="default.asp" target="_blank">行銷 Marketing</a></p>
    </button>
    <button type="button" class="btn-block" name="edit" id="4" onclick="btn4(); return false;">
      <p><a href="default.asp" target="_blank">管理 Management</a></p>
    </button>
    <button type="button" class="btn-block" name="edit" id="5" onclick="btn5(); return false;">
      <p><a href="default.asp" target="_blank">數學 Math and algebra</a></p>
    </button>

  
          <button type="button" class="btn-block " name="show" id="1" onclick="btn1(); return false;" style="display:none">
            財金 Finance
            <button type="button" class="btn-block" name="show" id="7" onclick="acc1(); return false;" style="display:none">
             <a href="-1.php">會計Accounting</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="31" onclick="acc1(); return false;" style="display:none">
             <a href="2.php">財務報表分析</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="32" onclick="acc1(); return false;" style="display:none">
             <a href="3.php">信用風險</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="33" onclick="acc1(); return false;" style="display:none">
             <a href="4.php">經濟 Economics</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="9" onclick="acc1(); return false;" style="display:none">
             <a href="5.php">投資學</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="10" onclick="acc1(); return false;" style="display:none">
             <a href="6.php">個體經濟學</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="11" onclick="acc1(); return false;" style="display:none">
             <a href="7.php">總體經濟學</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="39" onclick="acc1(); return false;" style="display:none">
             <a href="26.php">財務風險管理</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="40" onclick="acc1(); return false;" style="display:none">
             <a href="27.php">經濟學原理</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="41" onclick="acc1(); return false;" style="display:none">
             <a href="28.php">財務工程導論</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="42" onclick="acc1(); return false;" style="display:none">
             <a href="29.php">財務報表分析</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="43" onclick="acc1(); return false;" style="display:none">
             <a href="30.php">財務計量經濟學</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="44" onclick="acc1(); return false;" style="display:none">
             <a href="31.php">貨幣銀行與金融風暴</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="45" onclick="acc1(); return false;" style="display:none">
             <a href="32.php">金融創新</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="46" onclick="acc1(); return false;" style="display:none">
             <a href="33.php">創業與籌資</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="47" onclick="acc1(); return false;" style="display:none">
             <a href="34.php">實質選擇權與策略投資</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="48" onclick="acc1(); return false;" style="display:none">
             <a href="35.php">金融科技概論</a> 
              
             </button>
             <button type="button" class="btn-block" name="show" id="49" onclick="acc1(); return false;" style="display:none">
             <a href="36.php">投資學</a> 
              
            </button>
            <button type="button" class="btn-block" name="show" id="50" onclick="acc1(); return false;" style="display:none">
             <a href="37.php">期貨與選擇權</a> 
              
            </button>
            <button type="button" class="btn-block" name="show" id="51" onclick="acc1(); return false;" style="display:none">
             <a href="38.php">私募股權分析與金融投資實務</a> 
              
            </button>
            <button type="button" class="btn-block" name="show" id="52" onclick="acc1(); return false;" style="display:none">
             <a href="39.php">公司理財</a> 
              
            </button>
             <button type="button" class="btn-block" name="show" id="8" onclick="acc(); return false;" style="display:none">
             <a href="40.php">中級會計學(一)</a> 
             </button>
             <button type="button" class="btn-block" name="show" id="53" onclick="acc(); return false;" style="display:none">
             <a href="41.php">中級會計學(二)</a> 
             </button>
             <button type="button" class="btn-block" name="show" id="26" onclick="clo1(); return false;" style="display:none">
              close if finish
             </button>
          </button>
          <button type="button" class="btn-block " name="close" id="2" onclick="btn2(); return false;"style="display:none">
            資訊 Computer knowledge
           
             <button type="button" class="btn-block" name="show" id="12" onclick="acc2(); return false;" style="display:none">
             <a href="8.php">資料庫</a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="13" onclick="acc2(); return false;" style="display:none">
             <a href="9.php">計算機概論</a> 
             </button>
             <button type="button" class="btn-block" name="show" id="14" onclick="acc2(); return false;" style="display:none">
             <a href="11.php">資料結構</a> 
             </button>
             <button type="button" class="btn-block" name="show" id="15" onclick="acc2(); return false;" style="display:none">
             <a href="10.php">程式設計</a> 
             </button>
             <button type="button" class="btn-block" name="show" id="54" onclick="acc2(); return false;" style="display:none">
            <a href="42.php">資料科學</a>
            </button>
            <button type="button" class="btn-block" name="show" id="55" onclick="acc2(); return false;" style="display:none">
            <a href="43.php">演算法</a>
            </button>
            <button type="button" class="btn-block" name="show" id="56" onclick="acc2(); return false;" style="display:none">
            <a href="44.php">人工智慧與金融科技實務</a>
            </button>
            <button type="button" class="btn-block" name="show" id="57" onclick="acc2(); return false;" style="display:none">
            <a href="45.php">資訊安全與區塊鏈</a>
            </button>
            <button type="button" class="btn-block" name="show" id="58" onclick="acc2(); return false;" style="display:none">
            <a href="46.php">巨集程式開發與應用</a>
            </button>
            <button type="button" class="btn-block" name="show" id="59" onclick="acc2(); return false;" style="display:none">
            <a href="47.php">機器學習商業應用</a>
            </button>
            <button type="button" class="btn-block" name="show" id="60" onclick="acc2(); return false;" style="display:none">
            <a href="48.php">管理資訊系統</a>
            </button>
            <button type="button" class="btn-block" name="show" id="61" onclick="acc2(); return false;" style="display:none">
            <a href="49.php">基因演算法與管理科學應用</a>
            </button>
             <button type="button" class="btn-block" name="show" id="27" onclick="clo2(); return false;" style="display:none">
              close if finish
             </button>
            
          </button>
          <button type="button" class="btn-block " name="show" id="3" onclick="btn3(); return false;" style="display:none">
            行銷 Marketing
            
             <button type="button" class="btn-block" name="show" id="23" onclick="acc1(); return false;" style="display:none">
             <a href="12.php">行銷學</a> 
              
             </button>

             <button type="button" class="btn-block" name="show" id="24" onclick="acc3(); return false;" style="display:none">
              <a href="13.php">  行銷管理</a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="25" onclick="acc3(); return false;" style="display:none">
             <a href="14.php">  消費者行為</a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="36" onclick="acc3(); return false;" style="display:none">
             <a href="23.php">  商務談判</a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="37" onclick="acc3(); return false;" style="display:none">
             <a href="24.php"> 企業社會責任與行銷 </a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="38" onclick="acc3(); return false;" style="display:none">
             <a href="25.php"> 整合行銷溝通 </a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="28" onclick="clo3(); return false;" style="display:none">
              close if finish
             </button>
           </button>
          <button type="button" class="btn-block " name="close" id="4" onclick="btn4(); return false;"style="display:none">
            管理 Management
            <button type="button" class="btn-block" name="show" id="17" onclick="b4(); return false;" style="display:none">
              <a href="15.php">管理學 </a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="18" onclick="b4(); return false;" style="display:none">
              <a href="16.php">生產與作業管理 </a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="19" onclick="b4(); return false;" style="display:none">
              <a href="17.php"> 策略管理 </a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="20" onclick="b4(); return false;" style="display:none">
              <a href="18.php">國際企業管理 </a>
              
            </button>
            </button>
             <button type="button" class="btn-block" name="show" id="34" onclick="b4(); return false;" style="display:none">
              <a href="19.php">人力資源管理 </a>
              
            </button>
            </button>
             <button type="button" class="btn-block" name="show" id="35" onclick="b4(); return false;" style="display:none">
            <a href="20.php">  組織行為 </a>
              
            </button>
            <button type="button" class="btn-block" name="show" id="62" onclick="b4(); return false;" style="display:none">
            <a href="50.php">連鎖服務業經營管理 </a>
              
            </button>
            <button type="button" class="btn-block" name="show" id="63" onclick="b4(); return false;" style="display:none">
            <a href="51.php">品質管理 </a>
              
            </button>
            <button type="button" class="btn-block" name="show" id="64" onclick="b4(); return false;" style="display:none">
            <a href="52.php">工業工程與管理實務 </a>
              
            </button>
            <button type="button" class="btn-block" name="show" id="65" onclick="b4(); return false;" style="display:none">
            <a href="53.php">倉儲管理概論 </a>
              
            </button>
            <button type="button" class="btn-block" name="show" id="66" onclick="b4(); return false;" style="display:none">
            <a href="54.php">工業工程與管理概論 </a>
              
            </button>
            <button type="button" class="btn-block" name="show" id="67" onclick="b4(); return false;" style="display:none">
            <a href="55.php">運輸與配送管理 </a>
              
            </button>
            <button type="button" class="btn-block" name="show" id="68" onclick="b4(); return false;" style="display:none">
            <a href="56.php">國際物流管理 </a>
              
            </button>
            <button type="button" class="btn-block" name="show" id="69" onclick="b4(); return false;" style="display:none">
            <a href="57.php">物流運籌管理 </a>
              
            </button>
            <button type="button" class="btn-block" name="show" id="70" onclick="b4(); return false;" style="display:none">
            <a href="58.php">精實企業管理</a>
              
            </button>
          </button>
          <button type="button" class="btn-block" name="show" id="29" onclick="clo4(); return false;" style="display:none">
           close if finish
          </button>
          </button>
          <button type="button" class="btn-block" name="close" id="5" onclick="btn5(); return false;"style="display:none">
            數學 Math and algebra
            <button type="button" class="btn-block" name="show" id="21" onclick="acc5(); return false;" style="display:none">
            <a href="21.php"> 微積分</a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="22" onclick="acc5(); return false;" style="display:none">
               <a href="22.php">  線性代數</a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="71" onclick="acc5(); return false;" style="display:none">
               <a href="59.php">  數理統計</a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="72" onclick="acc5(); return false;" style="display:none">
               <a href="60.php"> 統計方法與資料分析</a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="73" onclick="acc5(); return false;" style="display:none">
               <a href="61.php">作業研究</a>
              
             </button>
             <button type="button" class="btn-block" name="show" id="74" onclick="acc5(); return false;" style="display:none">
               <a href="62.php">統計學</a>
              
             </button>

            </button>
            <button type="button" class="btn-block" name="show" id="30" onclick="clo5(); return false;" style="display:none">
             close if finish
            </button>
          </button>
          <button type="button" class="btn-block" name="close" id="6" onclick="clo(); return false;"style="display:none">
            close(press when finish searching)
          </button>
  
</div> 

        <div class="col-sm-4">
          <font style="text-shadow:5px 5px 5px #ff00aa;"><p class="font-weight-normal"><h2><button type="button" class="btn-block" name="edit" id="search" onclick="showDiv2(); return false;">
            <p><a href="default.asp" target="_blank">直接搜尋教授</a></p>
          </button> </h2></p></font>
          <form action="1.php" method="post"><h6>
教授姓名：<input type="text" name="PN"> <input type="submit" name="button" value="確認"></h6>

</form>

        
        
       
          <font style="text-shadow:5px 5px 5px #ff00aa;"><p class="font-weight-normal"><h2><button type="button" class="btn-block" name="edit" id="edit" onclick="showDiv1(); return false;">
        <p><a href="register.php" target="_blank">我要留下評論!</a></p>
          </button> </h2></p></font> 
          <font style="text-shadow:5px 5px 5px #ff00aa;"><p class="font-weight-normal"><h3><button type="button" class="btn-block" name="edit" id="search" onclick="showDiv2(); return false;">
            <p><a href="default.asp" target="_blank">各系所課程簡介</a></p>
          </button> </h3></p></font>
          <p><a href="default.asp" target="_blank"><a href="https://iem.nycu.edu.tw/%e5%ad%b8%e4%bd%8d%e5%ad%b8%e7%a8%8b/%e5%a4%a7%e5%ad%b8%e9%83%a8%e5%ad%b8%e5%a3%ab%e7%8f%ad/">工業工程與管理學系</a></a><br> </p>
          <p><a href="default.asp" target="_blank"><a href="https://imf.nctu.edu.tw/zh_tw/course1/course1_0">資訊金融與財務金融學系</a></a><br> </p>
          <p><a href="default.asp" target="_blank"><a href="
https://ms.nycu.edu.tw/zh_tw/course1" >管理科學系</a></a><br> </p>
          <p><a href="default.asp" target="_blank"><a href="https://tlm.nycu.edu.tw/zh/students/%e5%ad%b8%e5%a3%ab%e7%8f%ad/"   >運輸與物流管理學系</a></a><br> </p> 
           




</form></span> 


    
            
            
 
      
</div>
<script>
    var prevScrollpos = window.pageYOffset;
    window.onscroll = function() {
    var currentScrollPos = window.pageYOffset;
      if (prevScrollpos > currentScrollPos) {
        document.getElementById("navbar").style.top = "0";
      } else {
        document.getElementById("navbar").style.top = "-50px";
      }
      prevScrollpos = currentScrollPos;
    }
    </script>     
</body> 
</body>   
</html>
</html>